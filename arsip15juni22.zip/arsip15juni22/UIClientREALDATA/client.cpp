#include "client.h"
#include "datasetup.h"
#include "QWebSocket"
#include "qwt_plot_curve.h"
#include "qwt_legend.h"
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>


QT_USE_NAMESPACE

EchoClient::EchoClient(QObject *parent) :
    QObject(parent)
{
    //websocket

    //waktu
//    jam = new QTimer(this);
//    connect(jam, SIGNAL(timeout()),this, SLOT(showTime()));
//    jam->start();
//    date = QDate::currentDate();
//    dateTimeText = date.toString();
   // init grafik
//    plot.setTitle( "Plot Demo" );
//    plot.setCanvasBackground( Qt::white );
//    plot.insertLegend( new QwtLegend() );
//    plot.setAxisAutoScale(QwtPlot::yLeft, true);
//    curve = new QwtPlotCurve();
//    curve->attach( &plot );
//    plot.show();
}







