#include "grafik.h"

grafik::grafik()
{

}

void grafik::tampil()
{

}
